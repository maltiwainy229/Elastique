//
//  elastique_welcome_screenApp.swift
//  elastique welcome screen
//
//  Created by Ali Hamdani on 8/1/24.
//

import SwiftUI

@main
struct elastique_welcome_screenApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
