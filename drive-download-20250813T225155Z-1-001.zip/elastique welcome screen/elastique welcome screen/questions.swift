//
//  questions.swift
//  elastique welcome screen
//
//  Created by Ali Hamdani on 8/1/24.
//


import SwiftUI

struct QuestionnaireView: View {
    @State private var age: Double = 25
    @State private var gender: Double = 0 // 0 for Male, 1 for Female
    @State private var stretchingGoal: Double = 0
    @State private var sessionTime: Double = 30
    @State private var focusArea: Double = 0
    
    var body: some View {
        VStack(alignment: .leading, spacing: 20) {
            Text("Please answer the following questions!")
                .font(.custom("Roboto", size: 24))
                .foregroundColor(Color(hex: "#173B45"))
                .padding(.bottom, 20)
            
            Group {
                QuestionSlider(title: "What is your age?", value: $age, range: 18...100)
                QuestionSlider(title: "What is your gender?", value: $gender, range: 0...1, labelFormat: ["Male", "Female"])
                QuestionSlider(title: "What is your primary goal for stretching?", value: $stretchingGoal, range: 0...5)
                QuestionSlider(title: "How much time do you want to dedicate to stretching each session?", value: $sessionTime, range: 5...60, unit: "min")
                QuestionSlider(title: "Which areas of the body would you like to focus on?", value: $focusArea, range: 0...5)
            }
            
            Spacer()
            
            Button(action: {
                // Action for Continue button
            }) {
                Text("Continue")
                    .font(.custom("Roboto", size: 18))
                    .foregroundColor(Color(hex: "#FCF6EE"))
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color(hex: "#173B45"))
                    .cornerRadius(10)
            }
        }
        .padding()
        .background(Color(hex: "#FCF6EE"))
        .font(.custom("Roboto", size: 18))
    }
}

struct QuestionSlider: View {
    var title: String
    @Binding var value: Double
    var range: ClosedRange<Double>
    var unit: String = ""
    var labelFormat: [String]? = nil
    
    var body: some View {
        VStack(alignment: .leading) {
            Text(title)
                .font(.custom("Roboto", size: 18))
                .foregroundColor(Color(hex: "#173B45"))
            Slider(value: $value, in: range)
                .accentColor(Color(hex: "#FF8225"))
            Text(labelText)
                .font(.custom("Roboto", size: 16))
                .foregroundColor(Color(hex: "#B43F3F"))
        }
    }
    
    var labelText: String {
        if let format = labelFormat {
            let index = Int(value)
            return format[safe: index] ?? ""
        } else {
            return "\(Int(value)) \(unit)"
        }
    }
}

// Color extension for HEX codes
extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3: // RGB (12-bit)
            (a, r, g, b) = (255, (int >> 8) * 17, (int >> 4 & 0xF) * 17, (int & 0xF) * 17)
        case 6: // RGB (24-bit)
            (a, r, g, b) = (255, int >> 16, int >> 8 & 0xFF, int & 0xFF)
        case 8: // ARGB (32-bit)
            (a, r, g, b) = (int >> 24, int >> 16 & 0xFF, int >> 8 & 0xFF, int & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(
            .sRGB,
            red: Double(r) / 255,
            green: Double(g) / 255,
            blue: Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}

// Safe index array access
extension Collection {
    subscript(safe index: Index) -> Element? {
        return indices.contains(index) ? self[index] : nil
    }
}
