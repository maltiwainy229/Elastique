//
//  ContentView.swift
//  elastique welcome screen
//
//  Created by Ali Hamdani on 8/1/24.
//

import SwiftUI
import LocalAuthentication

struct ContentView: View {
    @State private var email = "Email"
    @State private var password = "Password"
    
    var body: some View {
        VStack {
            Spacer()
            
            Text("Welcome!")
                .font(.largeTitle)
                .foregroundStyle(Color(red: 23 / 255, green: 59 / 255, blue: 69 / 255))
                .fontWeight(.bold)
                .padding(.bottom, 8)
            
            Text("Please log in below")
                .font(.headline)
                .foregroundStyle(Color(red: 23 / 255, green: 59 / 255, blue: 69 / 255))
            
            VStack(spacing: 16) {
                TextField("Email", text: $email)
                    .padding()
                    .background(Color(red: 23 / 255, green: 59 / 255, blue: 69 / 255))
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .padding(.horizontal, 20)
                    .autocapitalization(.none)
                    .disableAutocorrection(true)
                
                SecureField("Password", text: $password)
                    .padding()
                    .background(Color(red: 23 / 255, green: 59 / 255, blue: 69 / 255))
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .padding(.horizontal, 20)
                    .autocapitalization(.none)
                    .disableAutocorrection(true)
                
                Button(action: {
                    // Handle sign-in action
                }) {
                    Text("Sign In")
                        .foregroundColor(Color(red: 180 / 255, green: 63 / 255, blue: 63 / 255))
                        .fontWeight(.bold)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .cornerRadius(10)
                        .shadow(radius: 5)
                }
                .padding(.horizontal, 20)
                
                Button(action: {
                    // Handle forgot password action
                }) {
                    Text("Forgot password?")
                        .font(.caption)
                        .foregroundColor(.blue)
                }
            }
            .padding(.top, 20)
            
            Spacer()
            
            VStack(spacing: 12) {
                Button(action: {
                    // Handle Sign in with Apple action
                }) {
                    HStack {
                        Image(systemName: "applelogo")
                        Text("Sign in with Apple")
                            .fontWeight(.bold)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.black)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .shadow(radius: 5)
                }
                .padding(.horizontal, 20)
                
                Button(action: {
                    // Handle Sign in with Facebook action
                }) {
                    HStack {
                        Image(systemName: "f.square.fill")
                            .foregroundColor(.white)
                        Text("Sign in with Facebook")
                            .fontWeight(.bold)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .shadow(radius: 5)
                }
                .padding(.horizontal, 20)
                
                // Biometric Login Button
                Button(action: {
                    authenticateWithBiometrics { success in
                        if success {
                            // Handle successful authentication
                            print("Biometric authentication successful.")
                        } else {
                            // Handle failed authentication
                            print("Biometric authentication failed.")
                        }
                    }
                }) {
                    HStack {
                        Image(systemName: "faceid")
                            .foregroundColor(.white)
                        Text("Login with Face ID / Touch ID")
                            .fontWeight(.bold)
                    }
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.green)
                    .foregroundColor(.white)
                    .cornerRadius(10)
                    .shadow(radius: 5)
                }
                .padding(.horizontal, 20)
            }
            
            Spacer()
        }
        .background(Color(red: 252 / 255, green: 246 / 255, blue: 238 / 255))
    }
    
    // Biometric Authentication Method
    func authenticateWithBiometrics(completion: @escaping (Bool) -> Void) {
        let context = LAContext()
        var error: NSError?
        
        // Check if the device supports biometric authentication
        if context.canEvaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, error: &error) {
            let reason = "Please authenticate to log in."
            
            context.evaluatePolicy(.deviceOwnerAuthenticationWithBiometrics, localizedReason: reason) { success, authenticationError in
                DispatchQueue.main.async {
                    completion(success)
                }
            }
        } else {
            // Biometrics not available
            DispatchQueue.main.async {
                completion(false)
            }
        }
    }
}

