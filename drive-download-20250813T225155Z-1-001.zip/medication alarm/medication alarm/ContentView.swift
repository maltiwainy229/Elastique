
import SwiftUI
import UserNotifications
import AVFAudio
import AVFoundation

struct ContentView: View {
    @State private var selectedTime = Date()
    @State private var medicationName = ""
    @State private var medicationList: [(String, String)] = [("7:00 AM", "Tylenol")]
    @State private var player: AVAudioPlayer?
    @State private var selectedSound: String = ""
    
    var elements: [menuSection] = [menuSection(rows: [menuRow(title: "Alarm", alarmSound: "alarm"), menuRow(title: "Classic", alarmSound: "classic")]), menuSection(rows: [menuRow(title: "iPhone Alarm", alarmSound: "iphone_15_alarm"), menuRow(title: "Remix", alarmSound: "iphone_remix")]), menuSection(rows: [menuRow(title: "Eunkike", alarmSound: "iphone_tone_eunike"), menuRow(title: "Samsung", alarmSound: "samsung")])]
    
    
    private var formattedTime: String {
        let formatter = DateFormatter()
        formatter.dateFormat = "h:mma"
        return formatter.string(from: selectedTime)
    }
    
    private func requestNotificationPermission() {
        UNUserNotificationCenter.current().requestAuthorization(options: [.alert, .sound, .badge]) { granted, error in
            if let error = error {
                print("Notification permission error: \(error)")
            }
        }
    }
    
    private func scheduleNotification(at date: Date, medicationName: String) {
        let content = UNMutableNotificationContent()
        content.title = "Medication Reminder"
        content.body = "Time to take your \(medicationName)"
        content.sound = UNNotificationSound.default
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: Calendar.current.dateComponents([.hour, .minute], from: date), repeats: false)
        let request = UNNotificationRequest(identifier: UUID().uuidString, content: content, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request) { error in
            if let error = error {
                print("Notification scheduling error: \(error)")
            }
        }
    }
    
    private func saveAlarm() {
        let timeString = formattedTime
        if !medicationName.isEmpty {
            medicationList.append((timeString, medicationName))
            scheduleNotification(at: selectedTime, medicationName: medicationName)
            medicationName = ""
        }
    }
    
    private func deleteAlarm(at offsets: IndexSet) {
        medicationList.remove(atOffsets: offsets)
    }
    
    func playSound(alarmSound: String) {
        guard let soundURL = Bundle.main.url(forResource: selectedSound, withExtension: "mp3") else {
            return
        }
        
        do {
            player = try AVAudioPlayer(contentsOf: soundURL)
        } catch {
            print("Failed to load the sound: \(error)")
        }
        player?.play()
    }
    
    var body: some View {
        ZStack {
            Color(red: 252 / 255, green: 246 / 255, blue: 238 / 255)
                .edgesIgnoringSafeArea(.all)
            
            VStack {
                Spacer()
                Spacer()
                Spacer()
                VStack(spacing: 60) {
                    Text("Medication Alarm")
                        .font(.largeTitle)
                        .onAppear {
                            requestNotificationPermission()
                        }
                    
                    HStack {
                        DatePicker("", selection: $selectedTime, displayedComponents: .hourAndMinute)
                            .labelsHidden()
                            .datePickerStyle(WheelDatePickerStyle())
                            .colorScheme(.dark)
                            .padding(.leading, 20)
                            .background(
                                RoundedRectangle(cornerRadius: 15)
                                    .fill(Color(red: 23 / 255, green: 59 / 255, blue: 69 / 255)
                                        .opacity(0.9))
                                    .frame(width: 299, height: 200)
                                    .padding(.top, 10)
                                    .padding(.leading, 25)
                                
                            )
                        
                        VStack {
                            Button(action: {
                                saveAlarm()
                            }) {
                                Text("Save")
                                    .font(.title)
                                    .padding()
                                    .frame(minWidth: 100, minHeight: 50)
                                    .background(Color.orange)
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                                    .padding(.bottom, 5)
                                    .padding()
                            }.padding(.leading,-29)
                            //                        Picker(selection: $selectedSound, label: Text("Select Sound")) {
                            //                            ForEach(soundNames, id: \.self) {
                            //                                Text($0)
                            //                            }
                            //                        }
                            //                        .padding()
                            //
                            //                        Button(action: {
                            //                            self.playSound()
                            //                        }) {
                            //                            Text("Play Sound")
                            //                        }
                            
                            
                            //                    }
                            
                            Menu {
                                
                                ForEach(elements.reversed(), id: \.self) { section in
                                    Section(content: {
                                        
                                        ForEach(section.rows.reversed()) { row in
                                            sectionElementButton(title: row.title, alarmSound: row.alarmSound)
                                        }
                                        
                                    })
                                }
                                
                            } label: {
                                Circle()
                                    .fill(.gray.opacity(0.15))
                                    .frame(width: 30, height: 30)
                                    .padding(.leading, -40)
                                    .overlay {
                                        Image(systemName: "ellipsis")
                                            .font(.system(size: 13.0, weight: .semibold))
                                            .foregroundColor(.pink)
                                            .padding(.leading, -32)   .padding(.top,1)
                                    }
                            }
                            
                        }
                    }
                    .padding(.leading, 1)
                    
                    ZStack {
                        RoundedRectangle(cornerRadius: 20)
                            .fill(Color(red: 180 / 255, green: 63 / 255, blue: 63 / 255))
                            .opacity(0.3)
                            .frame(width: 400, height: 75)
                        HStack {
                            TextField("Pick Time & Type Medication...", text: $medicationName)
                                .font(.title)
                                .padding(.leading, 50)
                        }
                    }
                    
                    // Display the list of alarms
                    List {
                        ForEach(medicationList, id: \.0) { time, medication in
                            HStack {
                                Text(time)
                                    .font(.headline)
                                Spacer()
                                Text(medication)
                                    .font(.headline)
                            }
                            .padding()
                            .background(Color(red: 228 / 255, green: 154 / 255, blue: 145 / 255))
                            .cornerRadius(10)
                        }
                        .onDelete(perform: deleteAlarm)
                    }.scrollContentBackground(.hidden)
                }
                .padding(.top, -50)
                Spacer()
            }
            .padding()
        }
    }
}
