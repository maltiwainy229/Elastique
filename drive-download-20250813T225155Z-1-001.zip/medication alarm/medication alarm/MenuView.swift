//
//  MenuView.swift
//  medication alarm
//
//  Created by Ali Hamdani on 8/7/24.
//

import SwiftUI
struct menuRow: Identifiable, Hashable {
    
    let id: String
    var title: String
    var alarmSound: String
    
    init(title: String, alarmSound: String) {
        self.id = UUID().uuidString
        self.title = title
        self.alarmSound = alarmSound
    }
    
}

struct menuSection: Identifiable, Hashable {
    
    
    let id: String
    let rows: [menuRow]
    
    init(rows: [menuRow]) {
        self.id = UUID().uuidString
        self.rows = rows
    }
    
}

@ViewBuilder
func sectionElementButton(title: String, alarmSound: String) -> some View {
    
    Button() {
        
    } label: {
        HStack {
            Text(title)
                .font(.system(size: 14.0, weight: .medium, design: .default))
                .foregroundColor(.white)
                .multilineTextAlignment(.leading)
     
          
        }
    }
    
    }
