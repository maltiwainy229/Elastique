//
//  medication_alarmApp.swift
//  medication alarm
//
//  Created by Ali Hamdani on 8/7/24.
//

import SwiftUI

@main
struct medication_alarmApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
