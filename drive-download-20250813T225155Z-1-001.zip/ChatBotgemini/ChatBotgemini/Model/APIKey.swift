//
//  APIKey.swift
//  ChatBotgemini
//
//  Created by Ali Hamdani on 8/2/24.
//

//View Model

import Foundation
import Combine
import GoogleGenerativeAI

class ChatBotViewModel: ObservableObject {
    let model: GenerativeModel
    @Published var messages: [String] = []
    
    init(){
        guard let value = Bundle.main.infoDictionary?["API_KEY"] as? String else {
            fatalError("NO KEY FOUND")
        }
        self.model = GenerativeModel(name: "gemini-1.5-flash-latest", apiKey: value)
    }
    
    func genAnswer(question: String) async throws {
        do {
            let response = try await model.generateContent(question)
            let answer = response.text ?? "Bad Request, try again"
            DispatchQueue.main.async {
                self.messages.append("You: \(question)")
                self.messages.append("Elastique AI: \(answer)")
            }
        } catch {
            DispatchQueue.main.async {
                self.messages.append("You: \(question)")
                self.messages.append("Elastique AI: Error occurred")
            }
            throw error
        }
    }
}
