//
//  elastique_aiApp.swift
//  elastique ai
//
//  Created by Ali Hamdani on 8/2/24.
//

import SwiftUI

@main
struct elastique_aiApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
