//
//  ContentView.swift
//  elastique ai
//
//  Created by Ali Hamdani on 8/2/24.
//

import SwiftUI
import Combine

// ChatBot model for handling API interactions
class GPT3ChatBot: ObservableObject {
    // Store the API Key retrieved from Config.plist
    private let apiKey: String
    // API Endpoint URL
    private let apiURL = "https://api.openai.com/v1/engines/davinci-codex/completions"
    // Published messages for UI updates
    @Published var messages: [String] = []

    // Initialize with API Key from Config.plist
    init() {
        if let path = Bundle.main.path(forResource: "Config", ofType: "plist"),
           let xml = FileManager.default.contents(atPath: path),
           let config = try? PropertyListSerialization.propertyList(from: xml, format: nil) as? [String: Any],
           let key = config["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"] as? String {
            apiKey = key
        } else {
            fatalError("API Key is missing. Please set it in Config.plist.")
        }
    }

    // Send a message to OpenAI API
    func sendMessage(_ text: String) {
        // Combine user messages into a prompt for the AI
        let prompt = "\(messages.joined(separator: "\n"))\nUser: \(text)\nAI:"
        // Parameters for the API request
        let params: [String: Any] = [
            "prompt": prompt,
            "max_tokens": 150,
            "temperature": 0.7,
            "n": 1
        ]

        // Construct URL and request
        guard let url = URL(string: apiURL) else { return }
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        // Serialize parameters to JSON data
        guard let httpBody = try? JSONSerialization.data(withJSONObject: params, options: []) else { return }
        request.httpBody = httpBody

        // Perform network request
        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            guard let data = data, error == nil else {
                print("Error fetching data: \(String(describing: error))")
                return
            }

            // Parse JSON response
            if let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
               let choices = json["choices"] as? [[String: Any]],
               let text = choices.first?["text"] as? String {
                DispatchQueue.main.async {
                    // Append AI's response to messages
                    self?.messages.append("AI: \(text.trimmingCharacters(in: .whitespacesAndNewlines))")
                }
            }
        }.resume()
    }
}

// Main ContentView for the SwiftUI app
struct ContentView: View {
    // State object for managing the chat
    @StateObject private var chatBot = GPT3ChatBot()
    // State for user input text
    @State private var inputText = ""

    var body: some View {
        VStack {
            // List of chat messages
            List(chatBot.messages, id: \.self) { message in
                Text(message)
            }

            // Input field and send button
            HStack {
                TextField("Enter your message", text: $inputText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)

                Button(action: {
                    chatBot.messages.append("User: \(inputText)")
                    chatBot.sendMessage(inputText)
                    inputText = ""
                }) {
                    Text("Send")
                        .fontWeight(.bold)
                        .padding(.horizontal)
                        .padding(.vertical, 8)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
            }
            .padding()
        }
        .navigationTitle("ChatBot")
    }
}

// Preview provider for SwiftUI previews
struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}


