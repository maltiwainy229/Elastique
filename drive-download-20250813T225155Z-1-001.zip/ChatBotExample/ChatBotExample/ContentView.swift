//
//  ContentView.swift
//  ChatBotExample
//
//  Created by Ali Hamdani on 8/2/24.
//

import SwiftUI

// Main ContentView for the SwiftUI app
struct ContentView: View {
    // State object for managing the chat
    @StateObject private var chatBot = GPT3ChatBot()
    // State for user input text
    @State private var inputText = ""

    var body: some View {
        VStack {
            // List of chat messages
            List(chatBot.messages, id: \.self) { message in
                Text(message)
            }

            // Input field and send button
            HStack {
                TextField("Enter your message", text: $inputText)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.horizontal)

                Button(action: {
                    // Append user message to the list and call sendMessage asynchronously
                    chatBot.messages.append("User: \(inputText)")
                    Task {
                        await chatBot.sendMessage(inputText)
                    }
                    inputText = ""
                }) {
                    Text("Send")
                        .fontWeight(.bold)
                        .padding(.horizontal)
                        .padding(.vertical, 8)
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
            }
            .padding()
        }
        .navigationTitle("ChatBot")
    }
}

// Preview provider for SwiftUI previews
#Preview {
    ContentView()
}
