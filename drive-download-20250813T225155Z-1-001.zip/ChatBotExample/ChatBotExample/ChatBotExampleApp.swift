//
//  ChatBotExampleApp.swift
//  ChatBotExample
//
//  Created by Ali Hamdani on 8/2/24.
//

import SwiftUI

@main
struct ChatBotExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
