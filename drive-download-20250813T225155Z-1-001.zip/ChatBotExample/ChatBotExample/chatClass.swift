import Foundation
import SwiftUI
import Combine

@MainActor
class GPT3ChatBot: ObservableObject {
    private let apiKey: String
    private let apiURL = "https://api.openai.com/v1/chat/completions"
    @Published var messages: [String] = []

    init() {
        guard let path = Bundle.main.path(forResource: "Info", ofType: "plist"),
              let xml = FileManager.default.contents(atPath: path),
              let config = try? PropertyListSerialization.propertyList(from: xml, format: nil) as? [String: Any],
              let key = config["API_KEY"] as? String else {
            fatalError("API Key is missing. Please set it in Config.plist.")
        }
        apiKey = key
    }

    func sendMessage(_ text: String) async {
        let userMessage = ["role": "user", "content": text]
        var chatHistory = messages.map { message -> [String: String] in
            if message.starts(with: "User: ") {
                return ["role": "user", "content": String(message.dropFirst(6))]
            } else if message.starts(with: "AI: ") {
                return ["role": "assistant", "content": String(message.dropFirst(4))]
            }
            return ["role": "", "content": ""]
        }
        chatHistory.append(userMessage)

        let params: [String: Any] = [
            "model": "gpt-3.5-turbo",
            "messages": chatHistory,
            "max_tokens": 150,
            "temperature": 0.7,
        ]

        guard let url = URL(string: apiURL) else {
            print("Invalid API URL")
            return
        }

        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.addValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        request.addValue("application/json", forHTTPHeaderField: "Content-Type")

        guard let httpBody = try? JSONSerialization.data(withJSONObject: params, options: []) else {
            print("Failed to serialize JSON parameters")
            return
        }
        request.httpBody = httpBody

        do {
            let (data, _) = try await URLSession.shared.data(for: request)

            if let jsonString = String(data: data, encoding: .utf8) {
                print("Raw JSON response: \(jsonString)")
            } else {
                print("Failed to convert response data to string")
            }

            if let json = try JSONSerialization.jsonObject(with: data, options: []) as? [String: Any],
               let choices = json["choices"] as? [[String: Any]],
               let message = choices.first?["message"] as? [String: Any],
               let content = message["content"] as? String {
                self.messages.append("AI: \(content.trimmingCharacters(in: .whitespacesAndNewlines))")
            } else {
                print("Unexpected JSON structure")
//                print("JSON keys: \(json.keys)")
            }
        } catch {
            print("Error fetching data: \(error.localizedDescription)")
        }
    }
}
